.. highlight:: none

.. include:: ../CONTRIBUTING.rst
